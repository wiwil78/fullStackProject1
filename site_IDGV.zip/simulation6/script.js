document.addEventListener("DOMContentLoaded", function() {
    var images = document.querySelectorAll('.carousel img');
    var currentIndex = 0;

    function updateCarousel() {
        images.forEach(function(image, index) {
            image.classList.toggle('active', index === currentIndex);
        });
    }

    function nextImage() {
        currentIndex = (currentIndex + 1) % images.length;
        updateCarousel();
    }

    // Appel de la fonction nextImage toutes les 5 secondes (ajustez selon vos préférences)
    setInterval(nextImage, 5000);

    // Appel initial pour afficher la première image
    updateCarousel();
});
